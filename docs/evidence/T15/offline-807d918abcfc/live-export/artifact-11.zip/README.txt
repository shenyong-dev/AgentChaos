Run: python verify.py report.zip
The manifest verifies internal consistency, not source authenticity.
Compare the ZIP SHA256 with the authenticated download record.
Reports retain observed results and separately recorded reviews.
