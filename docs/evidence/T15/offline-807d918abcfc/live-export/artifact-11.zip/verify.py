"""Read-only verification: python verify.py report.zip"""
import hashlib,json,sys,zipfile
from pathlib import PurePosixPath
with zipfile.ZipFile(sys.argv[1]) as archive:
    names=archive.namelist()
    assert len(names)==len(set(names)), "duplicate members"
    for name in names:
        path=PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts, "unsafe path"
        assert "\\" not in name, "unsafe separator"
    manifest=json.loads(archive.read("manifest.json"))
    assert set(names)==set(manifest["files"])|{"manifest.json"}, "member list mismatch"
    for name,record in manifest["files"].items():
        value=archive.read(name)
        assert len(value)==record["bytes"], name
        assert hashlib.sha256(value).hexdigest()==record["sha256"], name
    print("Verified",len(manifest["files"]),"files.")
    print("Matching hashes do not establish Agent quality or semantic correctness.")
